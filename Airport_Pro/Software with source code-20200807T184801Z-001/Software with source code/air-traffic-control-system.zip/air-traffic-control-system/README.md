# air-traffic-control-system

PDSA Group Assignment to find the shortest path between two airports. We have used Dijkstra's algorithm to find shortest path in this project

## Contributors

[![Contributor](https://avatars1.githubusercontent.com/u/22878500?s=48&v=4)](https://github.com/juniorZed)
[![contributor](https://avatars1.githubusercontent.com/u/30007068?s=48&v=4)](https://github.com/tmjayalath)
